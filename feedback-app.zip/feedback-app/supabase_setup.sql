-- Run this in Supabase SQL Editor
create table feedback (
  id bigint generated always as identity primary key,
  created_at timestamptz default now(),
  q1_stars int,
  q1_text text,
  q2_radio text,
  q2_text text,
  q3_stars int,
  q3_text text,
  q4_radio text,
  q4_text text,
  q5_radio text,
  q5_text text,
  q6_radio text,
  q6_text text
);

-- Allow anonymous inserts (public can submit feedback)
alter table feedback enable row level security;

create policy "Allow anonymous insert" on feedback
  for insert with check (true);

create policy "Allow authenticated read" on feedback
  for select using (true);
